# JSON files for data sheet

In this folder, you will find the JSON files used to populate the Sheet file.

| Folder      | Description |
| ----------- | ----------- |
| :open_file_folder: [Scripts](https://github.com/jcwieme/data-scripts-star-wars/tree/master/3.%20JSON%20for%20sheet/scripts) | Files used to populate : speaker, listener, text, where, number words and time |
