# Markdown files

This folder contains the clean markdown files from the scripts. I only kept the dialogues and the places where they take place.

## Structure

The files are structured like this:

### For the scripts:

* The places are either h2 or *italic*
* The speaker and the listener are in **bold**
* The text follows after the **":"**

### For the characters:

For the characters, it's a simple list of all the talking character in the movie.
