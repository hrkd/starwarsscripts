# Sources

## Special thanks

In this folder, you will find all the source files that have been used to collect the data. Thank you very much to the people who wrote the scripts and the subtitles. Without them, this project would have taken much longer.

## Credits

| Links      | Description |
| ----------- | ----------- |
| [IMSDB](https://www.imsdb.com/) | Scripts from movies |
| [YIFY](https://yts-subs.com/) | Subtitles files |
